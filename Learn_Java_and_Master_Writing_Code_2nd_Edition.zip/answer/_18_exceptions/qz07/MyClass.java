package answer._18_exceptions.qz07;

public class MyClass
{
  public static void test(String str)
  {
    if (str == null)
    {
      throw new NullPointerException();
    }
    else
    {
      throw new RuntimeException();
    }
  }
  public static void main(String[] args)
  {
    try
    {
      System.out.print("A");
      test(null);
    }
    catch (NullPointerException e)
    {
      System.out.print("B");
    }
    catch (Exception e)
    {
      System.out.print("C");
    }
    finally
    {
      System.out.print("D");
    }
  }
}
