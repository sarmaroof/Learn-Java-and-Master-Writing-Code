package answer._18_exceptions.qz06;

public class MyClass
{
  static String str = "";

  static void calculate(int x, int y)
  {
    str += "A";
    if (y == 0)
    {
      throw new ArrayIndexOutOfBoundsException();
    }
    int z = x / y;
    str += "B";
  }
  public static void main(String[] args)
  {
    try
    {
      str += "C";
      calculate(10, 0);
      str += "D";
    }
    catch (ArithmeticException e)
    {
      str += "E";
    }
    catch (ArrayIndexOutOfBoundsException ae)
    {
      str += "F";
    }
    System.out.println(str);
  }
}
