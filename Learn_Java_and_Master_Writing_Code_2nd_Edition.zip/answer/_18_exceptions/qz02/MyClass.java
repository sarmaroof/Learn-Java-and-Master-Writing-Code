package answer._18_exceptions.qz02;

public class MyClass
{
  public void method()
  {
    try
    {
      int[] intArray = new int[5];
      int z = intArray[6];
      System.out.print("w");
    }
    catch (ArithmeticException e)
    {
      System.out.print("x");
    }
    catch (ArrayIndexOutOfBoundsException e)
    {
      System.out.print("y");
    }
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.method();
  }
}
