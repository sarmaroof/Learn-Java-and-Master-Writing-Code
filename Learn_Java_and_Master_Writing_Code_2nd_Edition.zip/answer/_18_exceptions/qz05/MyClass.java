package answer._18_exceptions.qz05;

public class MyClass
{
  StringBuffer sb;
  int z;

  public void myMethod()
  {
    try
    {
      sb.append("s");
      z = 5 / 0;
    }
    catch (NullPointerException e)
    {
      System.out.print("n");
    }
    catch (ArithmeticException ae)
    {
      System.out.print("a");
    }
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.myMethod();
  }
}
