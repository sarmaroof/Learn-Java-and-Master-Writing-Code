package answer._18_exceptions.qz01;

public class MyClass
{
  public void method()
  {
    try
    {
      System.out.print("x");
      int x = Integer.parseInt("38");
      System.out.print("y");
    }
    catch (NumberFormatException e)
    {
      System.out.print("z");
    }
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.method();
  }
}
