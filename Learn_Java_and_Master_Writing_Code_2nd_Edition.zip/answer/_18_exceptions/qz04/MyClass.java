package answer._18_exceptions.qz04;

public class MyClass
{
  int x = 20;

  public void method()
  {
    try
    {
      int i = 2 / x;
      System.out.print("a");
    }
    catch (NullPointerException n)
    {
      System.out.print("b");
    }
    catch (ArithmeticException e)
    {
      System.out.print("d");
    }
    finally
    {
      System.out.print("f");
    }
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.method();
  }
}
