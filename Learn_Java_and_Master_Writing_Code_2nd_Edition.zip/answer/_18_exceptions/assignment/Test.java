package answer._18_exceptions.assignment;

import java.util.ArrayList;

public class Test
{
  private static ArrayList<String> movieList = new ArrayList<String>();

  public static void populateList()
  {
    movieList.add("The Godfather");
    movieList.add("Titanic");
    movieList.add("Dances with Wolves");
    movieList.add("The Pianist");
    movieList.add("Wall Street");
    movieList.add("Amadeus");
  }
  public static String getMovie(int movieIndex) throws MyException
  {
    if (movieIndex >= movieList.size())
    {
      throw new MyException("The movie " + movieIndex + " does not exist.");
    }
    return movieList.get(movieIndex);
  }
  public static void main(String args[])
  {
    populateList();
    try
    {
      String movie = getMovie(15);
      System.out.print("The movie title is: " + movie);
    }
    catch (MyException me)
    {
      System.out.print(me.getMessage());
      // me.printStackTrace();
    }
  }
}
