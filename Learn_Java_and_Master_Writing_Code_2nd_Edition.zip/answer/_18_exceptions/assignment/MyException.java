package answer._18_exceptions.assignment;

public class MyException extends Exception
{
  public MyException(String message)
  {
    super(message);
  }
}
