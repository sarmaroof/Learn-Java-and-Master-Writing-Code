package answer._18_exceptions.qz03;

public class MyClass
{
  String str = "Boris";

  public void method()
  {
    try
    {
      str.substring(1);
      System.out.print("s");
    }
    catch (NullPointerException e)
    {
      System.out.print("x");
    }
    catch (Exception e)
    {
      System.out.print("y");
    }
    finally
    {
      System.out.print("z");
    }
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.method();
  }
}
