package answer._06_classes_objects_constructors.qz05;

class MyClass
{
  int x = 3;
  int y = 5;
  // answer 1
  int z;

  MyClass()
  {
    this(4, 6);
  }
  MyClass(int x, int y)
  {
    this.y = y;
  }
  // answer 2
  MyClass(int x, int y, int z)
  {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    MyClass mc2 = new MyClass(9, 7);
    System.out.println(mc.x + ", " + mc.y + ", " + mc2.x + ", " + mc2.y);
    // answer 3
    MyClass mc3 = new MyClass(7, 8, 9);
    // answer 4
    System.out.print("The answer is: ");
    System.out.print(mc3.x + ", " + mc3.y + ", " + mc3.z);
  }
}
