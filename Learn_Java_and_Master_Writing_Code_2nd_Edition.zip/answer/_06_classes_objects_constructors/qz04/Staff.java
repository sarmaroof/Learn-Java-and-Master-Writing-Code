package answer._06_classes_objects_constructors.qz04;

class Staff
{
  String name = "Ron";
  double salary = 400.0;

  Staff(String name)
  {
    this(name, 780.0);
  }
  Staff(String name, double salary)
  {
    this.name = name;
    this.salary = salary;
  }
  public static void main(String[] args)
  {
    Staff st = new Staff("Ben");
    System.out.println(st.name + ", " + st.salary);
    // answer 1
    Staff staffObject = new Staff("Mary", 2000.55);
    // answer 2
    System.out.print("The answer is: ");
    System.out.print(staffObject.name + ", " + staffObject.salary);
  }
}
