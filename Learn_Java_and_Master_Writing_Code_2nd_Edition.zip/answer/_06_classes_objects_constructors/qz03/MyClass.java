package answer._06_classes_objects_constructors.qz03;

class MyClass
{
  int x = 2;
  int y = 5;

  // no-argument constructor
  MyClass()
  {
    // answer 1
    this(6, 3);
  }
  // one-argument constructor
  MyClass(int x)
  {
    this.y = x;
  }
  // two-arguments constructor
  MyClass(int x, int y)
  {
    this.x = x;
    this.y = y;
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    MyClass mc2 = new MyClass(7);
    MyClass mc3 = new MyClass(9, 3);
    System.out.println(mc.y + ", " + mc2.y + ", " + mc3.x);
    // answer 2
    MyClass myObject = new MyClass();
    // answer 3
    System.out.print("The answer is: ");
    System.out.print("x = " + myObject.x + ", ");
    System.out.print("y = " + myObject.y);
  }
}
