package answer._06_classes_objects_constructors.qz01;

class Employee
{
  String name = "Anna";
  int age = 22;
  String phone;
  String city;

  public static void main(String[] args)
  {
    Employee em = new Employee();
    Employee em2 = new Employee();
    Employee employee = new Employee();
    
    employee.name = "Emma";
    employee.age = 25;
    employee.phone = "00233-786854";
    employee.city = "New York City";
    
    em.name = "John";
    em.age = 20;
    em.phone = "00383-384833";
    em.city = "London";
    
    System.out.println("-------- Employees -----------");
    System.out.println("Name:         " + em.name);
    System.out.println("Age:          " + em.age);
    System.out.println("Phone:        " + em.phone);
    System.out.println("City:         " + em.city);
    System.out.println("-------------------");
    System.out.println("Name:         " + employee.name);
    System.out.println("Age:          " + employee.age);
    System.out.println("Phone:        " + employee.phone);
    System.out.println("City:         " + employee.city);
  }
}
