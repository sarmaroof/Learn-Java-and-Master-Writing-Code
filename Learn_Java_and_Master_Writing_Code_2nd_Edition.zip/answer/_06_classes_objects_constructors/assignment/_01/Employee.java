package answer._06_classes_objects_constructors.assignment._01;

// the first method without constructors
class Employee
{
  String name;
  double salary = 2400.55;
  String country = "France";

  public static void main(String[] args)
  {
    Employee employee = new Employee();
    Employee employee2 = new Employee();
    employee.name = "Olivia";
    employee.salary = 3100.45;
    employee.country = "Canada";
    employee2.name = "James";
    System.out.println("-------- Employees -----------");
    System.out.println("Name:            " + employee.name);
    System.out.println("Salary:          $ " + employee.salary);
    System.out.println("Country:         " + employee.country);
    System.out.println("-----------------");
    System.out.println("Name:            " + employee2.name);
    System.out.println("Salary:          $ " + employee2.salary);
    System.out.println("Country:         " + employee2.country);
  }
}
