package answer._06_classes_objects_constructors.assignment._02;

// the second method using constructors
class Employee
{
  String name;
  double salary;
  String country;

  Employee(String name)
  {
    this.name = name;
    this.salary = 2400.55;
    this.country = "France";
  }
  Employee(String name, double salary, String country)
  {
    this.name = name;
    this.salary = salary;
    this.country = country;
  }
  public static void main(String[] args)
  {
    Employee employee = new Employee("Olivia", 3100.45, "Canada");
    Employee employee2 = new Employee("James");
    System.out.println("-------- Employees -----------");
    System.out.println("Name:             " + employee.name);
    System.out.println("Salary:           $ " + employee.salary);
    System.out.println("Country:          " + employee.country);
    System.out.println("-----------------");
    System.out.println("Name:             " + employee2.name);
    System.out.println("Salary:           $ " + employee2.salary);
    System.out.println("Country:          " + employee2.country);
  }
}
