package answer._06_classes_objects_constructors.qz02;

class MyClass
{
  int x;
  int y = 7;

  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    
    mc.x = 5;
    mc.y = 8;
    
    MyClass mc2 = new MyClass();
    MyClass mc3 = mc;
    
    System.out.println(mc.x + ", " + mc2.x + ", " + mc3.y);
    // answer
    System.out.print("The answer is: ");
    MyClass myClass = new MyClass();
    myClass = mc3;
    System.out.println(myClass.x + ", " + myClass.y);
  }
}
