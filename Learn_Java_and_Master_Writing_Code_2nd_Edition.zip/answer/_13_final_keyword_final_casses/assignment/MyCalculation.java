package answer._13_final_keyword_final_casses.assignment;

public class MyCalculation
{
  public static void main(String[] args)
  {
    System.out.println("The greater number is: " + Math.max(35, 46));
    System.out.println("The smaller number is: " + Math.min(46.98, 44.99));
    System.out.println("The rootof 81 is:      " + Math.sqrt(81.0));
    System.out.println("The random number is:  " + Math.random());
  }
}
