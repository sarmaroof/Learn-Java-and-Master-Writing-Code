package answer._13_final_keyword_final_casses.qz03;

public class MyClass extends MySuper
{
  int x = 3;

  String methodA(String s, int i)
  {
    String str = s + ", " + i;
    // super.x++;
    return str;
  }
  public static void main(String[] args)
  {
    MySuper ms = new MySuper();
    System.out.print(ms.methodA(23, "Emma"));
  }
}
