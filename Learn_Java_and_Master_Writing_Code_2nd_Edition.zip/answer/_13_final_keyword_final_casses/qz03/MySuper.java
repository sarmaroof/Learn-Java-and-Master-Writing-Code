package answer._13_final_keyword_final_casses.qz03;

public class MySuper
{
  final int x = 4;

  final String methodA(int i, String s)
  {
    String str = i + ", " + s;
    return str;
  }
}