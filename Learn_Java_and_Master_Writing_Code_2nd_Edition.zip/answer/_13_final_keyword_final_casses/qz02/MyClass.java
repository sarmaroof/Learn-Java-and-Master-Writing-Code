package answer._13_final_keyword_final_casses.qz02;

public class MyClass extends MySuper
{
  int z = 5;

  void method(int x)
  {
    System.out.print("x");
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
  }
}
