package answer._13_final_keyword_final_casses.qz02;

public class MySuper
{
  final void methodA()
  {
    System.out.print("x");
  }
  final void methodB(int i)
  {
    System.out.print("x" + i);
  }
  final void methodC(String str)
  {
    System.out.print("x");
  }
}