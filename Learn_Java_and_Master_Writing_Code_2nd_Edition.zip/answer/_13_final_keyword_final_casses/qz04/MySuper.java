package answer._13_final_keyword_final_casses.qz04;

public class MySuper
{
  final void methodeA(int x, double y)
  {
    double z = x * y;
    System.out.print(z);
  }
}
