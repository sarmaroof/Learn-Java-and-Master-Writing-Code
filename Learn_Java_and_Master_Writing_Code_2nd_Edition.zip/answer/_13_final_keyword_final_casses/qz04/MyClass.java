package answer._13_final_keyword_final_casses.qz04;

public final class MyClass extends MySuper
{
  void methodeA(int x, int y)
  {
    int z = x - y;
    System.out.print(z);
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    // mc.methodeA(5,3.0);
    mc.methodeA(6, 4);
  }
}
