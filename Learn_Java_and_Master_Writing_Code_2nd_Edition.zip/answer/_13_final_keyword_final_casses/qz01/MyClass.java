package answer._13_final_keyword_final_casses.qz01;

public final class MyClass
{
  final int x = 3;

  int getResult(int y, int z)
  {
    if (y >= z)
    {
      return y + x;
    }
    else
    {
      // insert code here
      return z + x;
    }
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    System.out.println(mc.getResult(4, 6));
  }
}
