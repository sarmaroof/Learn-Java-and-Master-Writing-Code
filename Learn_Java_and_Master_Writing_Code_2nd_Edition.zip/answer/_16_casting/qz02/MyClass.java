package answer._16_casting.qz02;

public class MyClass
{
  public static void main(String[] args)
  {
    int i = 122;
    i = 187; // answer
    double d = i;
    System.out.print(d);
  }
}
