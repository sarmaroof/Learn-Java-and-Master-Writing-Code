package answer._16_casting.qz03;

public class MySub extends MySuper
{
  int i = 3;

  public int method()
  {
    return 2 * i;
  }
  public static void main(String[] args)
  {
    MySuper s = new MySub();
    // Answer 1, 2
    MySub ms = (MySub) s;
    // Answer 3
    System.out.println(" " + ms.i + ", " + ms.method());
    System.out.println(" " + s.i + ", " + s.method());
  }
}
