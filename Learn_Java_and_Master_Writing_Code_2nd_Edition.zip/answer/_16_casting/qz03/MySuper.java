package answer._16_casting.qz03;

public class MySuper
{
  protected int i = 5;

  public int method()
  {
    return 2 * i;
  }
}
