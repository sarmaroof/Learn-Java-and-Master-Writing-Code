package answer._16_casting.assignment;

import java.util.ArrayList;
import java.util.List;

public class MyList
{
  List<String> list = new ArrayList<String>();
  ArrayList<String> aList = new ArrayList<String>();

  public static void main(String[] args)
  {
    MyList mc = new MyList();
    mc.aList.clone();
    mc.list.clone();
  }
}
