package answer._16_casting.qz04;

public class MySuper
{
  protected int x;

  MySuper()
  {
    x++;
    System.out.print("N");
  }
  int myMethod()
  {
    return x + 3;
  }
}
