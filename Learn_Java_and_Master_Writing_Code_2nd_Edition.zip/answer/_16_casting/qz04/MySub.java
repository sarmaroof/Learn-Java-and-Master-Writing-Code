package answer._16_casting.qz04;

public class MySub extends MySuper
{
  MySub()
  {
    x += 2;
    System.out.print("P");
  }
  int myMethod()
  {
    return x + 4;
  }
  public static void main(String[] args)
  {
    MySuper ms = new MySuper();
    System.out.print(ms.myMethod());
  }
}
