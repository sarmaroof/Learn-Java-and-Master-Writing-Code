package answer._16_casting.qz01;

public class MyClass
{
  public static void main(String[] args)
  {
    int i1 = 127;
    int i2 = 134;
    byte b1 = (byte) i1;
    byte b2 = (byte) i2;
    System.out.print(b1 + ", ");
    System.out.println(b2);
    // answer
    System.out.print("The answer is: ");
    int myInt = i1 + i2;
    System.out.print(myInt);
    // short myShort = i1;
  }
}
