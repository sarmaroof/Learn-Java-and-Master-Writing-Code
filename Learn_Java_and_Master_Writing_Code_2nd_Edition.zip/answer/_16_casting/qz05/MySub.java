package answer._16_casting.qz05;

public class MySub extends MySuper
{
  public void method()
  {
    System.out.print("t");
  }
  public static void main(String[] args)
  {
    // MySuper ms = new MySub();
    // Answer 1
    MySuper ms = new MySuper();
    ms.method(3);
  }
}
