package answer._16_casting.qz05;

public class MySuper
{
  public MySuper()
  {
    System.out.print("m");
  }
  public void method()
  {
    System.out.print("s");
  }
  public void method(int i)
  {
    method();
    System.out.print("k" + i);
  }
}
