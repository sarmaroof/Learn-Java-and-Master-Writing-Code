package answer._14_abstract_classes.qz01;

public class MyClass extends MyAbstract
{
  int getSum()
  {
    return x + 5;
  }
  int getSum(int x)
  {
    return super.x + x;
  }
  void printMyName(String name)
  {
    System.out.print("Name: " + name);
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    System.out.println(mc.getSum(4));
    mc.printMyName("Emily");
  }
}
