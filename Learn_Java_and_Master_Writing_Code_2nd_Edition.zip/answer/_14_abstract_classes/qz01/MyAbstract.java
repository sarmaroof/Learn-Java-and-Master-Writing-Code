package answer._14_abstract_classes.qz01;

public abstract class MyAbstract
{
  protected int x = 6;

  public MyAbstract()
  {
    x += 2;
  }
  abstract int getSum(int x);
  abstract void printMyName(String name);
}