package answer._14_abstract_classes.qz04;

public abstract class MyClassB
{
  MyClassB()
  {
    System.out.print("a");
  }
  public abstract int getResult(int x, int y);
}
