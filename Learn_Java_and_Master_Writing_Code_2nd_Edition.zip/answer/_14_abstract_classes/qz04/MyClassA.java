package answer._14_abstract_classes.qz04;

public class MyClassA extends MyClassB
{
  MyClassA()
  {
    System.out.print("b");
  }
  MyClassA(int i)
  {
    System.out.print("d" + i);
  }
  public int getResult(int x, int y)
  {
    return x * y;
  }
}
