package answer._14_abstract_classes.qz04;

public class MyClass extends MyClassA
{
  MyClass(int i)
  {
    System.out.print("c" + i);
  }
  public static void main(String[] args)
  {
    new MyClass(4);
    new MyClassA(4);
  }
}
