package answer._14_abstract_classes.qz03;

public class MyClass extends MyAbstract
{
  MyClass()
  {
    this(2);
    str += 7;
  }
  MyClass(int x)
  {
    str += x;
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    System.out.print(mc.str);
  }
}
