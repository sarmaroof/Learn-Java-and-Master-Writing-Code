package answer._14_abstract_classes.qz03;

abstract class MyAbstract
{
  String str = "N";

  MyAbstract()
  {
    this("O");
    str += "L";
  }
  MyAbstract(String str)
  {
    this.str += str;
  }
}
