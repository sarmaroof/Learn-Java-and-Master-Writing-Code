package answer._14_abstract_classes.assignment;

import java.util.Calendar;

public class DateAndTime
{
  public static void main(String[] args)
  {
    Calendar now = Calendar.getInstance();
    System.out.println(now.getTime());
  }
}
