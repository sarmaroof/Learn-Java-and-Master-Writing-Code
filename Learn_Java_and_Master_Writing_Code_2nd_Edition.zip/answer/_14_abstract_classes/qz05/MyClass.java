package answer._14_abstract_classes.qz05;

public class MyClass extends MyAbstract
{
  void methodeA()
  {
    System.out.print("x");
  }
  void methodeA(int x)
  {
    System.out.print("y" + x);
  }
  String methodeB(String s)
  {
    return s + x;
  }
  String methodeB(int x)
  {
    return "x" + x;
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.methodeA();
    System.out.println(mc.methodeB("y"));
    // Methode 1
    System.out.println("The price is: " + mc.getPrice(33));
    // Methode 2
    System.out.println("The price is: " + MyAbstract.getPrice2(33));
  }
}
