package answer._14_abstract_classes.qz05;

public abstract class MyAbstract
{
  int x;

  abstract void methodeA();
  abstract String methodeB(String s);
  // Methode 1
  public double getPrice(double price)
  {
    return price;
  }
  // Methode 2
  public static double getPrice2(double price)
  {
    return price;
  }
}
