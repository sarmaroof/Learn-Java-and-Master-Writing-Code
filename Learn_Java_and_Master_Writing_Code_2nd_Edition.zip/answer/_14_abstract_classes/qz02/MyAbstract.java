package answer._14_abstract_classes.qz02;

public abstract class MyAbstract
{
  MyAbstract()
  {
    System.out.print("n");
  }
  abstract void printLetter(char c);
}
