package answer._14_abstract_classes.qz02;

public class MySuper extends MyAbstract
{
  MySuper()
  {
  }
  MySuper(int i)
  {
    System.out.print(i);
  }
  void printLetter(char c)
  {
    System.out.print(c);
  }
}
