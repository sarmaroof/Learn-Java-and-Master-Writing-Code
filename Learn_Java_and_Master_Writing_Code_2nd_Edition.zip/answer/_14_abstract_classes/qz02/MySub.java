package answer._14_abstract_classes.qz02;

public class MySub extends MySuper
{
  MySub()
  {
    super(10);
    System.out.print("p");
  }
  public static void main(String[] args)
  {
    new MySub().printLetter('s');
  }
}
