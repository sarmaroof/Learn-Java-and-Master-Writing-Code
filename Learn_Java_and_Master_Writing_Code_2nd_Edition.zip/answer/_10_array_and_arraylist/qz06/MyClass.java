package answer._10_array_and_arraylist.qz06;

public class MyClass
{
  void myMethod()
  {
    // Answer 1
    String strArray[] = { "n", "b", "a", "z" };
    for (int i = 0; i < strArray.length; i++)
    {
      if (strArray[i].equals("z"))
      {
        System.out.print("x1 ");
      }
      else if (strArray[i].equals("a"))
      {
        System.out.print("x2 ");
      }
      else if (strArray[i].equals("b"))
      {
        System.out.print("x2 ");
      }
      else
      {
        System.out.print("x3 ");
      }
    }
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.myMethod();
  }
}
