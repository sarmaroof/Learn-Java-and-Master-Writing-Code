package answer._10_array_and_arraylist.qz07;

import java.util.ArrayList;

public class CountryList
{
  public static void main(String[] args)
  {
    ArrayList<String> countries = new ArrayList<String>();
    countries.add("Germany");
    countries.add("United States");
    countries.add("Russia");
    countries.add("United Kingdom");
    countries.add(2, "India");
    System.out.println("");
    System.out.println("- Before removing Germany from the list -");
    
    for (int i = 0; i < countries.size(); i++)
    {
      System.out.print(" " + countries.get(i));
    }
    System.out.println("");
    System.out.println("");
    System.out.println("-------- Countries -------");
    System.out.println("Is the list  empty: " + countries.isEmpty());
    System.out.println("Check Spain :       " + countries.contains("Spain"));
    System.out.println("Check Russia:       " + countries.contains("Russia"));
    System.out.println("Index US: " + countries.indexOf("United States"));
    System.out.println("The size:           " + countries.size());
    // Germany is the first country on the list, its index is 0
    countries.remove(0);
    System.out.println("");
    System.out.println("- After removing Germany from the list -");
    
    for (int i = 0; i < countries.size(); i++)
    {
      System.out.print(" " + countries.get(i));
    }
  }
}
