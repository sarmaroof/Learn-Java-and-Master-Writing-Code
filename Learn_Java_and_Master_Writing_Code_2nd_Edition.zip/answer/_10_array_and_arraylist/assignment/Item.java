package answer._10_array_and_arraylist.assignment;

public class Item
{
  String name;
  double price;

  public Item(String name, double price)
  {
    this.name = name;
    this.price = price;
  }
}