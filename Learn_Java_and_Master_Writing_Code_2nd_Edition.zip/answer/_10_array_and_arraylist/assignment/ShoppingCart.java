package answer._10_array_and_arraylist.assignment;

import java.util.ArrayList;

public class ShoppingCart
{
  // String[] shoppingCart = new String[4];
  private ArrayList<Item> items = new ArrayList<Item>();

  public void printItems()
  {
    for (int i = 0; i < items.size(); i++)
    {
      System.out.println("Item: " + items.get(i).name + ", Price: " + items.get(i).price);
    }
  }
  public static void main(String[] args)
  {
    Item item = new Item("Shirt", 20.39);
    Item item2 = new Item("Pants", 32.85);
    Item item3 = new Item("Socks", 11.25);
    Item item4 = new Item("Coat ", 120.65);
    
    ShoppingCart sc = new ShoppingCart();
    
    sc.items.add(item);
    sc.items.add(item2);
    sc.items.add(item3);
    sc.items.add(item4);
    
    sc.printItems();
  }
}
