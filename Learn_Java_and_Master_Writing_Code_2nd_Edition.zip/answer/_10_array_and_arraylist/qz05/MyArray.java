package answer._10_array_and_arraylist.qz05;

import java.util.Arrays;

public class MyArray
{
  public static void main(String[] args)
  {
    char[] arrCharA = new char[4];
    arrCharA[0] = 'w';
    arrCharA[1] = 'k';
    arrCharA[2] = 'd';
    arrCharA[3] = 'r';
    char[] arrCharB = arrCharA.clone();
    // returns the index of the element 'k'
    int i = Arrays.binarySearch(arrCharA, 'k');
    // checks whether the two arrays are equal
    boolean b = Arrays.equals(arrCharA, arrCharB);
    // System.out.print(i + " " + b);
    // Answer 1
    char[] arrayChar = new char[8];
    arrayChar[0] = 'R';
    arrayChar[1] = 'N';
    arrayChar[2] = 'B';
    arrayChar[3] = 'S';
    arrayChar[4] = 'M';
    arrayChar[5] = 'O';
    arrayChar[6] = 'A';
    arrayChar[7] = 'C';
    // Answer 2
    boolean isEqual = Arrays.equals(arrayChar, arrCharA);
    System.out.println("Is arrayChar equal to arrCharA? " + isEqual);
    // Answer 3
    Arrays.sort(arrayChar);
    // Answer 4
    for (int x = 0; x < arrayChar.length; x++)
    {
      System.out.print(arrayChar[x] + ", ");
    }
  }
}
