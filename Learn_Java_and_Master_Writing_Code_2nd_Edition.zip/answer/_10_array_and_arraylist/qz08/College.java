package answer._10_array_and_arraylist.qz08;

import java.util.ArrayList;

public class College
{
  private ArrayList<Student> studentList = new ArrayList<Student>();

  public void populateStudentArray()
  {
    Student st1 = new Student(" Smith", 24, "smith@itmail.com");
    Student st2 = new Student(" Jennifer", 22, "jennifer@dzork.com");
    Student st3 = new Student(" Thomas", 33, "thomas@ysmail.com");
    Student st4 = new Student(" Susan", 25, "susan@rzmail.com");
    Student st5 = new Student(" Rita", 28, "rita@online.com");
    
    studentList.add(st1);
    studentList.add(st2);
    studentList.add(st3);
    studentList.add(st4);
    studentList.add(st5);
  }
  public static void main(String[] args)
  {
    College cl = new College();
    cl.populateStudentArray();
    
    for (int i = 0; i < cl.studentList.size(); i++)
    {
      System.out.print(cl.studentList.get(i).name +
          ", " + cl.studentList.get(i).age +
          ", " + cl.studentList.get(i).email);
    }
  }
}
