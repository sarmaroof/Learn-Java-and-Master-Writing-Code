package answer._10_array_and_arraylist.qz08;

public class Student
{
  String name;
  int age;
  String email;

  public Student(String name, int age, String email)
  {
    this.name = name;
    this.age = age;
    this.email = email;
  }
}