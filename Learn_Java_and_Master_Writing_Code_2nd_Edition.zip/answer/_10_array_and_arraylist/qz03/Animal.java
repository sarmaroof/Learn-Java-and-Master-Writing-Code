package answer._10_array_and_arraylist.qz03;

import java.util.Arrays;

public class Animal
{
  public static void main(String[] args)
  {
    // answer 2
    String[] arrAnimal = new String[8];
    arrAnimal[0] = "Wolf ";
    arrAnimal[1] = "Lion ";
    arrAnimal[2] = "Leopard ";
    arrAnimal[3] = "Elephant ";
    arrAnimal[4] = "Tiger ";
    // answer 1
    arrAnimal[5] = "Bear ";
    arrAnimal[6] = "Zebra ";
    arrAnimal[7] = "Monkey ";
    // see the class "Arrays" of the Java standard API
    
    Arrays.sort(arrAnimal);
    // answer 3
    for (int i = 0; i < arrAnimal.length; i++)
    {
      System.out.println(arrAnimal[i]);
    }
  }
}
