package answer._10_array_and_arraylist.qz01;

public class MyArray
{
  public static void main(String[] args)
  {
    // answer
    int[] arrayInt = new int[11];
    for (int i = 0; i < arrayInt.length; i++)
    {
      System.out.print(arrayInt[i] + " ");
    }
  }
}
