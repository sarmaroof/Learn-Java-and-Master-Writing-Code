package answer._09_packages_access_modifiers.qz03.package_02;

public class ClassB
{
  public int w = 1;
  protected int x = 2;
  int y = 3;
  private int z = 4;

  public void myMethod()
  {
    System.out.print(w);
    System.out.print(x);
    System.out.print(y);
    System.out.print(z);
  }
}
