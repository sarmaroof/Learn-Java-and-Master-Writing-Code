package answer._09_packages_access_modifiers.qz03.package_01;

import answer._09_packages_access_modifiers.qz03.package_02.ClassB;

public class ClassA
{
  public static void main(String[] args)
  {
    ClassB cb = new ClassB();
    cb.myMethod();
  }
}
