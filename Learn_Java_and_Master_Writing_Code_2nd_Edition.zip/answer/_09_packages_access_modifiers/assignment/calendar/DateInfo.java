package answer._09_packages_access_modifiers.assignment.calendar;

public class DateInfo
{
  private int day = 16;
  private int month = 3;
  private int year = 1998;

  public DateInfo(int day, int month, int year)
  {
    this.day = day;
    this.month = month;
    this.year = year;
  }
  public String getDateFormat()
  {
    return month + "-" + day + "-" + year;
  }
}
