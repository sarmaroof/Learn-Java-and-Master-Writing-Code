package answer._09_packages_access_modifiers.assignment.personal_data;

import answer._09_packages_access_modifiers.assignment.calendar.DateInfo;

public class Student
{
  private String name;
  private DateInfo birthDate;

  public static void main(String[] args)
  {
    Student isab = new Student();
    Student dav = new Student();
    
    DateInfo bdIsab = new DateInfo(28, 8, 1998);
    DateInfo bdDav = new DateInfo(13, 9, 1996);
    
    isab.name = "Isabella";
    isab.birthDate = bdIsab;
    
    dav.name = "David";
    dav.birthDate = bdDav;
    
    System.out.println("---First Student---");
    System.out.println("Name: " + isab.name);
    System.out.println("Birth date: " + isab.birthDate.getDateFormat());
    System.out.println("---Second Student---");
    System.out.println("Name: " + dav.name);
    System.out.println("Birth date: " + dav.birthDate.getDateFormat());
  }
}
