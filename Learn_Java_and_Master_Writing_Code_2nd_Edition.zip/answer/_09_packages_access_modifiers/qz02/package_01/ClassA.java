package answer._09_packages_access_modifiers.qz02.package_01;

import answer._09_packages_access_modifiers.qz02.package_02.ClassB;

public class ClassA
{
  public static void main(String[] args)
  {
    ClassB cb = new ClassB();
    // System.out.print(cb.w); /* 1 */
    // System.out.print(cb.myInt);
    // System.out.print(cb.x); /* 2 */
    // System.out.print(cb.y); /* 3 */
    // System.out.print(cb.z); /* 4 */
    // answer 2
    System.out.print(cb.myInt);
  }
}
