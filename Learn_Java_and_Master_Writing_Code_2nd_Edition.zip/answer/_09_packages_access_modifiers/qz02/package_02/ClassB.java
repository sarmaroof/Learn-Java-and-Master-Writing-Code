package answer._09_packages_access_modifiers.qz02.package_02;

public class ClassB
{
  public int w = 1;
  protected int x = 2;
  int y = 3;
  private int z = 4;
  // answer 1
  public int myInt;
}
