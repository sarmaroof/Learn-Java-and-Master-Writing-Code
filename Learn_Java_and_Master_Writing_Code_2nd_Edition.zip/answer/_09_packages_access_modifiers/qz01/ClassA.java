package answer._09_packages_access_modifiers.qz01;

public class ClassA
{
  public static void main(String[] args)
  {
    ClassB cb = new ClassB();
    // System.out.print(cb.w); /* 1 */
    // System.out.print(cb.x); /* 2 */
    // System.out.print(cb.y); /* 3 */
    // System.out.print(cb.z); /* 4 */
    // Answer 2
    // System.out.print(cb.myChar);
  }
}
