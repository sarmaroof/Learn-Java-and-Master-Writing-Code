package answer._05_iteration_statements.qz10;

class MiniTheater
{
  public static void main(String[] args)
  {
    for (int row = 1; row <= 5; row++)
    {
      for (int column = 1; column < 4; column++)
      {
        if (row == 1 || row == 3)
        {
          continue;
        }
        System.out.print(row + "," + column + " ");
      }
    }
  }
}
