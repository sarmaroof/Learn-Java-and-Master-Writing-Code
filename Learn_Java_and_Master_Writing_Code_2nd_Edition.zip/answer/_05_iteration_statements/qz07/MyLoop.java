package answer._05_iteration_statements.qz07;

class MyLoop
{
  public static void main(String[] args)
  {
    char c = 'a';
    char c2 = 'b';
    // answer
    for (int i = 4; i >= 0; i--)
    {
      if (i < 2 || i == 4)
      {
        System.out.print(c2);
      }
      else
      {
        System.out.print(c);
      }
    }
  }
}
