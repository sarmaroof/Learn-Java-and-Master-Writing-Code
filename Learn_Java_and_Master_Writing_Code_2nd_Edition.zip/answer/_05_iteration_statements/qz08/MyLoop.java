package answer._05_iteration_statements.qz08;

class MyLoop
{
  public static void main(String[] args)
  {
    int x = 14;
    int y = 5;
    
    for (int i = 0; i < 10; i++)
    {
      x += 2;
      y += 5;
      if (x >= 21)
      {
        // break;
      }
    }
    System.out.print(y);
  }
}
