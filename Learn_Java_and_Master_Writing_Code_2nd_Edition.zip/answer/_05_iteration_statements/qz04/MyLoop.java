package answer._05_iteration_statements.qz04;

class MyLoop
{
  public static void main(String[] args)
  {
    int i = 2;
    
    do
    {
      i += 3;
      if (i != 4)
      {
        System.out.print("x");
      }
      else
      {
        System.out.print("y");
      }
    }
    while (i < 10);
  }
}
