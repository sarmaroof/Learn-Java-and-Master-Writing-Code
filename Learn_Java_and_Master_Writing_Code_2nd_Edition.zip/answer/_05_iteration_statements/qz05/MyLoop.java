package answer._05_iteration_statements.qz05;

class MyLoop
{
  public static void main(String[] args)
  {
    // answer
    for (int i = 1; i < 10; i += 3)
    {
      System.out.print(i);
    }
  }
}
