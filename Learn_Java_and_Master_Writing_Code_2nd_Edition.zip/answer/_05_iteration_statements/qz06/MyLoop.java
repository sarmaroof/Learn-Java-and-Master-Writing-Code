package answer._05_iteration_statements.qz06;

class MyLoop
{
  public static void main(String[] args)
  {
    int x = 1;
    // answer
    for (int i = 3; i < 13; i += 5)
    {
      x += i;
    }
    x -= 2;
    System.out.print(x);
  }
}
