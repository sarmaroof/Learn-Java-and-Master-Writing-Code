package answer._05_iteration_statements.qz02;

class MyLoop
{
  public static void main(String[] args)
  {
    int i = 8;
    
    while (i > 1)
    {
      i++;
      System.out.print(i);
      // answer
      // i -= 5;
    }
  }
}
/*
Question

If you remove the statement "i -= 5" from the program, the program loops endlessly. 
   What is your explanation for that?
   
Answer
The statement "while(i > 1)" returns always true, because i is equal to 8 and each time
the loop is executed the statement "i ++" increments the value of i by one. 
The value of i remains greater than one forever. 

*/