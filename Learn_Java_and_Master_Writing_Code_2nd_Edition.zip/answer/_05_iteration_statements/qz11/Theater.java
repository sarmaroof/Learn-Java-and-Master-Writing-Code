package answer._05_iteration_statements.qz11;

class Theater
{
  public static void main(String[] args)
  {
    outer:for (int row = 1; row < 4; row++)
    {
      inner:for (int column = 1; column < 5; column++)
      {
        if (column == 2 && column == 3)
        {
          break inner;
        }
        System.out.print(row + "," + column + " ");
      }
    }
  }
}
