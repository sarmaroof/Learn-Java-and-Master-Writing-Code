package answer._05_iteration_statements.qz09;

class LeapYear
{
  public static void main(String[] args)
  {
    for (int jaar = 2016; jaar <= 2040; jaar++)
    {
      if ((jaar % 4 == 0))
      {
        // continue;
      }
      System.out.print(jaar + " ");
    }
  }
}
