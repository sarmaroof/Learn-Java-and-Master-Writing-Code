package answer._05_iteration_statements.qz03;

class MyLoop
{
  public static void main(String[] args)
  {
    int i = 4;
    
    do
    {
      i += 6;
      System.out.print(i);
    }
    while (i <= 12);
  }
}
