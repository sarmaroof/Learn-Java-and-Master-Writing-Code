package answer._05_iteration_statements.qz01;

class MyLoop
{
  public static void main(String[] args)
  {
    int i = 5;
    
    while (i > 1)
    {
      i--;
      System.out.print(i);
    }
  }
}
