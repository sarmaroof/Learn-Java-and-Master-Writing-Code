package answer._12_inheritance.qz05;

public class MySub extends MySuper
{
  int method(int i, int i2)
  {
    return method(i) + x + i2;
  }
  public static void main(String[] args)
  {
    MySub mySub = new MySub();
    System.out.print(mySub.method(2, 8));
  }
}
