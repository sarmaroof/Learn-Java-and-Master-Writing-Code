package answer._12_inheritance.qz05;

public class MySuper
{
  protected int x = 2;

  int method(int i)
  {
    return x + i;
  }
}
