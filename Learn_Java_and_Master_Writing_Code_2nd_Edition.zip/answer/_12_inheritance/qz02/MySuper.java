package answer._12_inheritance.qz02;

public class MySuper
{
  protected int x = 1;

  MySuper()
  {
    x += 2;
  }
}
