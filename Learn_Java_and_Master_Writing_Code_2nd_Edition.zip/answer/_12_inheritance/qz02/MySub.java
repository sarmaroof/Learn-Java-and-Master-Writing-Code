package answer._12_inheritance.qz02;

public class MySub extends MySuper
{
  MySub(int y)
  {
    x += y;
  }
  public static void main(String[] args)
  {
    MySub ms = new MySub(4);
    MySub ms2 = new MySub(6);
    System.out.print(ms2.x);
  }
}
