package answer._12_inheritance.assignment;

public class Truck extends Vehicle
{
  private double maxLoad;

  public Truck(String brand, int manufactureYear, String color, double maxLoad)
  {
    super(brand, manufactureYear, color);
    this.maxLoad = maxLoad;
  }
  public void print()
  {
    System.out.println("---Truck---");
    super.print();
    System.out.println("Maximum Load:  " + maxLoad);
  }
}