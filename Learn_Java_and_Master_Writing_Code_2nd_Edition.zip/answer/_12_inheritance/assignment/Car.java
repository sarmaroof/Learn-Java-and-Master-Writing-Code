package answer._12_inheritance.assignment;

public class Car extends Vehicle
{
  private int maxNrPassenger;

  public Car(String brand, int manufactureYear, String color, int maxNrPassenger)
  {
    super(brand, manufactureYear, color);
    this.maxNrPassenger = maxNrPassenger;
  }
  public void print()
  {
    System.out.println("--Car---");
    super.print();
    System.out.println("Max passengers: " + maxNrPassenger);
  }
}