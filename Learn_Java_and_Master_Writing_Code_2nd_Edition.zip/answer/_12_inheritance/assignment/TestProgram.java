package answer._12_inheritance.assignment;

public class TestProgram
{
  public static void main(String[] args)
  {
    Truck tk1 = new Truck("BMW", 2016, "green", 6550);
    Truck tk2 = new Truck("Volvo", 2014, "black", 4000);
    
    Car car1 = new Car("Toyota", 2013, "red", 5);
    Car car2 = new Car("Mazda", 2017, "blue", 8);
    
    car1.print();
    car2.print();
    tk1.print();
    tk2.print();
  }
}
