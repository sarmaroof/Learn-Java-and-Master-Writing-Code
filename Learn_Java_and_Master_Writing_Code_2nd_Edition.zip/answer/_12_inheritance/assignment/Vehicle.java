package answer._12_inheritance.assignment;

public class Vehicle
{
  protected String brand;
  protected int manufactureYear;
  protected String color;

  public Vehicle(String brand, int manufactureYear, String color)
  {
    this.brand = brand;
    this.manufactureYear = manufactureYear;
    this.color = color;
  }
  public void print()
  {
    System.out.println("Brand:            "+brand);
    System.out.println("Manufacture year: "+manufactureYear);
    System.out.println("Color:            "+color);
  }
}