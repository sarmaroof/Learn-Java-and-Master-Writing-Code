package answer._12_inheritance.qz03;

public class MySuper
{
  protected char c = 'G';

  MySuper()
  {
    System.out.print('Q');
  }
  void method()
  {
    System.out.print(c);
  }
}