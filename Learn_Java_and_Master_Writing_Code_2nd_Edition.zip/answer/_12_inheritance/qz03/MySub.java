package answer._12_inheritance.qz03;

class MySub extends MySuper
{
  char c2 = 'A';

  MySub()
  {
    this('N');
    System.out.print(c2);
  }
  MySub(char c)
  {
    System.out.print(c);
  }
  void method()
  {
    super.method();
    System.out.print(c2);
  }
  public static void main(String[] args)
  {
    MySub mySub = new MySub();
    mySub.method();
  }
}
