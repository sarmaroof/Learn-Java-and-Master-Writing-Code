package answer._12_inheritance.qz08.package_01;

import answer._12_inheritance.qz08.package_02.MySuper;

public class MySub extends MySuper
{
  public static void main(String[] args)
  {
    MySuper mySuper = new MySuper();
    MySub mySub = new MySub();
    // System.out.print(mySuper.str1); /* 1 */
    // System.out.print(mySuper.str2); /* 2 */
    // System.out.print(mySuper.str3); /* 3 */
    // System.out.print(mySuper.str4); /* 4 */
    // System.out.print(mySub.str2); /* 5 */
    // System.out.print(mySub.str1);
    // Answer 2, 3
    // System.out.print(mySuper.myInt); // mySuper cannot access myInt
    System.out.print(mySub.myInt); // mySub can access myInt
  }
}
