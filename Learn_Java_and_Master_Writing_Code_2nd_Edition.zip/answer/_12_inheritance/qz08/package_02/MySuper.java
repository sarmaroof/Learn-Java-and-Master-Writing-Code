package answer._12_inheritance.qz08.package_02;

public class MySuper
{
  public String str1 = "String 1";
  protected String str2 = "String 2";
  String str3 = "String 3";
  private String str4 = "String 4";
  // answer 1
  protected int myInt;
}