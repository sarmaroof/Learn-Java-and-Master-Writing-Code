package answer._12_inheritance.qz06;

public class MySuper
{
  protected int x = 3;
  protected char e = 'd';

  void myMethod()
  {
    x += 4;
    System.out.print(e);
    System.out.print(x);
  }
}