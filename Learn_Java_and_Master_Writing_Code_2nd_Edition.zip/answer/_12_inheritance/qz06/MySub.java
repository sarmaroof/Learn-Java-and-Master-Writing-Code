package answer._12_inheritance.qz06;

public class MySub extends MySuper
{
  char e = 'p';

  void myMethod()
  {
    x++;
    System.out.print(e);
    super.myMethod();
    x += 2;
    System.out.print(x);
  }
  public static void main(String[] args)
  {
    MySub ms = new MySub();
    ms.myMethod();
  }
}
