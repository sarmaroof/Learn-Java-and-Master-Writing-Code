package answer._12_inheritance.qz04;

public class SuperA extends SuperB
{
  int y = 7;

  public SuperA()
  {
    y++;
    System.out.print(" y" + y);
  }
}
