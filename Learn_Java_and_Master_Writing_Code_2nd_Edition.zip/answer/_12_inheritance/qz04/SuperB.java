
package answer._12_inheritance.qz04;

public class SuperB
{
  protected int x = 3;

  public SuperB()
  {
    x += 2;
    System.out.print(" x" + x);
  }
}
