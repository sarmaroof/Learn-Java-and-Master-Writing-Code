package answer._12_inheritance.qz04;

public class MySub extends SuperA
{
  int x;

  public MySub()
  {
    x += 2;
    y += 3;
    System.out.print(" x" + x);
    System.out.print(" y" + y);
  }
  public static void main(String[] args)
  {
    MySub mySub = new MySub();
  }
}
