package answer._12_inheritance.qz07;

public class MySuper
{
  MySuper(String name)
  {
    this(name, "d");
    System.out.print(name);
  }
  MySuper(String name, String name2)
  {
    System.out.print(name);
    System.out.print(name2);
  }
}