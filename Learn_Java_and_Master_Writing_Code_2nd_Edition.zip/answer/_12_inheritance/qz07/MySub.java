package answer._12_inheritance.qz07;

public class MySub extends MySuper
{
  MySub(String name)
  {
    super("s");
    System.out.print(name);
  }
  public static void main(String[] args)
  {
    MySub ms = new MySub("x");
  }
}
