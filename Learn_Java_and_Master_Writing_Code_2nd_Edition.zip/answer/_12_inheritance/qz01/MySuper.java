package answer._12_inheritance.qz01;

public class MySuper
{
  protected int x = 5;
}
