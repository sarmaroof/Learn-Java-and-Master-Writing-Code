package answer._12_inheritance.qz01;

public class MySub extends MySuper
{
  private int y = 8;

  MySub()
  {
    x += 2;
    y++;
    System.out.print(x + ", " + y);
  }
  public static void main(String[] args)
  {
    MySub ms = new MySub();
  }
}
