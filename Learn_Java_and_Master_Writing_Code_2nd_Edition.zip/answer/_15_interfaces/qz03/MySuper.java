package answer._15_interfaces.qz03;

public abstract class MySuper implements MyInterface
{
  public void myMethod()
  {
    System.out.print("m" + x);
  }
}
