package answer._15_interfaces.qz03;

public class MyClass extends MySuper
{
  // int x = 6;
  public void myMethod(String s)
  {
    myMethod();
    System.out.print("q" + s + x);
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.myMethod("w");
  }
}
