package answer._15_interfaces.qz03;

public interface MyInterface
{
  int x = 4;

  void myMethod();
  void myMethod(String str);
}
