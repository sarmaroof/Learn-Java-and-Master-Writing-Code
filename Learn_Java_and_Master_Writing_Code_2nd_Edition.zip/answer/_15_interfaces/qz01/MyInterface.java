package answer._15_interfaces.qz01;

public interface MyInterface
{
  int x = 5;

  void methode();
  void methode(int i);
}
