package answer._15_interfaces.qz02;

public class MyClass implements InterfaceA,InterfaceB
{
  // int MAX_ALLOWED; /*1*/
  int z = 2;

  public void myMethod()
  {
    z = MAX_ALLOWED + 4;
    System.out.print("H");
  }
  public void myMethod(char j)
  {
    // MAX_ALLOWED += 3; /* 2*/
    myMethod();
    System.out.print(j);
    System.out.print(z);
  }
  public int getSum()
  {
    return MAX_ALLOWED + z;
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.myMethod();
  }
}
