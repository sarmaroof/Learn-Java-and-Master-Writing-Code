package answer._15_interfaces.qz02;

public interface InterfaceB
{
  int MAX_ALLOWED = 3;

  int getSum();
}
