package answer._15_interfaces.qz02;

public interface InterfaceA
{
  void myMethod();
  void myMethod(char c);
}
