package answer._15_interfaces.assignment;

public interface Payable
{
  double getSalary();
}
