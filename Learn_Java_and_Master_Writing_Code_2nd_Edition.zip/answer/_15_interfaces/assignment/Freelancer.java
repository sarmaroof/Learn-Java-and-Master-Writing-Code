package answer._15_interfaces.assignment;

public class Freelancer implements Payable
{
  int workingHours;
  double hourlyRate;

  public Freelancer(int workingHours, double hourlyRate)
  {
    this.workingHours = workingHours;
    this.hourlyRate = hourlyRate;
  }
  public double getSalary()
  {
    double salary = workingHours * hourlyRate;
    return salary;
  }
}
