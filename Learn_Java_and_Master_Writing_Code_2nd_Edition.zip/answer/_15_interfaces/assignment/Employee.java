package answer._15_interfaces.assignment;

public class Employee implements Payable
{
  double taxRate = 0.30;
  double salary;

  public Employee(double salary)
  {
    this.salary = salary;
  }
  public double getSalary()
  {
    double netSalary = salary - (salary * taxRate);
    return netSalary;
  }
}
