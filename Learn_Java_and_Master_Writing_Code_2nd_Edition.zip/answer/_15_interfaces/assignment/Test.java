package answer._15_interfaces.assignment;

public class Test
{
  public static void main(String[] args)
  {
    Employee emp = new Employee(3000.0);
    Freelancer fr = new Freelancer(140, 60);
    System.out.println("The employee wage is:   $ " + emp.getSalary());
    System.out.println("The freelancer wage is: $ " + fr.getSalary());
  }
}
