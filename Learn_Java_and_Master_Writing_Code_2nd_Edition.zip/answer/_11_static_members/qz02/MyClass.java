package answer._11_static_members.qz02;

public class MyClass
{
  static int x = 3;

  public MyClass()
  {
    x++;
  }
  public static int method(int i, int i2)
  {
    x += (i - i2);
    return x;
  }
  // answer 1
  public static void resetX(int resetNummer)
  {
    x = resetNummer;
  }
  public static void main(String[] args)
  {
    MyClass mk1 = new MyClass();
    MyClass mk2 = new MyClass();
    System.out.print(MyClass.x + ", ");
    MyClass mk3 = new MyClass();
    MyClass.method(8, 3);
    System.out.print(MyClass.x + ", ");
    // answer 2
    System.out.println("");
    MyClass.resetX(0);
    System.out.println(MyClass.x);
    MyClass.resetX(10);
    System.out.println(MyClass.x);
    MyClass.resetX(100);
    System.out.println(MyClass.x);
  }
}
