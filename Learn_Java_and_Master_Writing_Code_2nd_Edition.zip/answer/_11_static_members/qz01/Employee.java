package answer._11_static_members.qz01;

public class Employee
{
  int nr; // instance variable
  static int stNr; // class variable

  public Employee()
  {
    nr++;
    stNr++;
  }
  public static void main(String[] args)
  {
    Employee emp1 = new Employee();
    Employee emp2 = new Employee();
    Employee emp3 = new Employee();
    // answer 1
    Employee emp4 = new Employee();
    Employee emp5 = new Employee();
    // answer 2, check the value of stNr
    System.out.print(Employee.stNr + ", ");
    System.out.print(emp1.nr + ", ");
    System.out.print(emp2.nr + ", ");
    System.out.print(emp3.nr);
  }
}
