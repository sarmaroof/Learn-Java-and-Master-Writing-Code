package answer._11_static_members.assignment;

public class ProgrammingLanguage
{
  static int numberOfLanguages;
  static String language = "";

  ProgrammingLanguage(String lg)
  {
    numberOfLanguages++;
    language += lg;
  }
  public static void main(String[] args)
  {
    ProgrammingLanguage pl1 = new ProgrammingLanguage("Java, ");
    ProgrammingLanguage pl2 = new ProgrammingLanguage("C++, ");
    ProgrammingLanguage pl3 = new ProgrammingLanguage("Python, ");
    ProgrammingLanguage pl4 = new ProgrammingLanguage("PHP, ");
    ProgrammingLanguage pl5 = new ProgrammingLanguage("Ruby");
    System.out.println("Nr: " + ProgrammingLanguage.numberOfLanguages);
    System.out.println("Languages: " + ProgrammingLanguage.language);
  }
}
