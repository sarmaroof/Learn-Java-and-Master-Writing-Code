package answer._11_static_members.qz04;

public class MyClass
{
  static int x = 2;

  MyClass()
  {
    x++;
  }
  static void methodA(int i)
  {
    x = x - i;
  }
  int methodB(int i)
  {
    return x + i;
  }
  public static void main(String[] args)
  {
    MyClass mc1 = new MyClass();
    MyClass.methodA(2);
    MyClass mc2 = new MyClass();
    System.out.print(mc2.methodB(3));
  }
}
