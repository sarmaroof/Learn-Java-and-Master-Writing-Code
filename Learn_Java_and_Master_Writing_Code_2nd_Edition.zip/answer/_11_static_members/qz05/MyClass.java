package answer._11_static_members.qz05;

public class MyClass
{
  int x;
  StringBuffer sb = new StringBuffer();

  public MyClass()
  {
    myMethod();
  }
  public void myMethod()
  {
    x += 3;
    sb.append(x);
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    MyClass mc2 = new MyClass();
    MyClass mc3 = new MyClass();
    System.out.println(mc.sb);
  }
}
