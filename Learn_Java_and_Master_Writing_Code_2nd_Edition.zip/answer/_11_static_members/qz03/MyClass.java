package answer._11_static_members.qz03;

public class MyClass
{
  static int x = 6;
  int y = 3;

  MyClass()
  {
    x += 3;
    y += 2;
  }
  void method(int i)
  {
    this.y = y - i;
    x++;
  }
  public static void main(String[] args)
  {
    MyClass mc1 = new MyClass();
    MyClass mc2 = new MyClass();
    MyClass mc3 = new MyClass();
    mc1.method(3);
    // answer 1, 2, 3
    MyClass mc4, mc5, mc6, mc7, mc8;
    System.out.print(mc2.x + ", " + mc1.y);
  }
}
