package answer._07_methods.qz05;

class Currency
{
  //dollar exchange rate
  double euro = 0.907; // $1 = � 0.907
  double britishPound = 0.762; // $1 = � 0.762
  double swissFranc = 0.986; // $1 = 0.986 CHF
  double chineseYuan = 6.674; // $1 = � 6.674
  double russianRuble = 64.459; // $ 1 = 64.459; RUB


  void convertToDollar(char valuta, int bedrag) 
  {
    switch (valuta)
    {
      case ('e'):
        System.out.print(bedrag * euro);
        break;
      case ('p'):
        System.out.print(bedrag * britishPound);
        break;
      case ('f'):
        System.out.print(bedrag * swissFranc);
        break;
      case ('y'):
        System.out.print(bedrag * chineseYuan);
        break;
      case ('r'):
        System.out.print(bedrag * russianRuble);
        break;
      default:
        System.out.print("Invalid");
    }
  }
  // answer 1
  double convertEuroToChineseYuan(double amountEuro)
  {
    double chineseYuan = amountEuro * (6.674 / 0.907);
    return chineseYuan;
  }
  public static void main(String[] args)
  {
    Currency cr = new Currency();
    // cr.convertToDollar('y',100);
    // answer 2, 3
    System.out.println("� 100 = � " + cr.convertEuroToChineseYuan(100));
    System.out.println("� 220 = � " + cr.convertEuroToChineseYuan(220));
    System.out.println("� 300 = � " + cr.convertEuroToChineseYuan(300));
    System.out.println("� 2   = � " + cr.convertEuroToChineseYuan(2));

  }
}
