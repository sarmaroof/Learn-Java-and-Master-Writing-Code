package answer._07_methods.qz03;

public class MyClass
{
  int i = 3;
  int i2 = 8;

  MyClass()
  {
    i += 4;
    i2 += 2;
  }
  void print()
  {
    int x = i + i2;
    System.out.print(x);
  }
  // answer 1
  double getNetSalary(double grossSalary, double taxRate)
  {
    double taxAmount = grossSalary * taxRate;
    double netSalary = grossSalary - taxAmount;
    return netSalary;
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    // mc.print();
    // answer 2
    System.out.println("Calculate net salary, tax rate = 20%: ");
    System.out.println("$ 3000 is $ " + mc.getNetSalary(3000, 0.20));
    System.out.println("$ 2400 is $ " + mc.getNetSalary(2400, 0.20));
    System.out.println("$ 1466 is $ " + mc.getNetSalary(1466, 0.20));
    System.out.println("Calculate net salary, tax rate = 30%: ");
    System.out.println("$ 3000 is $ " + mc.getNetSalary(3000, 0.30));
    System.out.println("$ 2400 is $ " + mc.getNetSalary(2400, 0.30));
    System.out.println("$ 1466 is $ " + mc.getNetSalary(1466, 0.30));
  }
}
