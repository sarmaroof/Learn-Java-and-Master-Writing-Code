package answer._07_methods.qz06;

class MyClass
{
  void myMethod(int x, int y)
  {
    int z = 4;
    int i = 3;
    i++;
    
    if (x < y)
    {
      z += 4;
    }
    if (x * x > y)
    {
      z += 2;
    }
    else
    {
      z += 6;
    }
    z++;
    System.out.print(z);
  }
  // answer 1
  int getSmallestNumber(int w, int x, int y)
  {
    int smallest = 0;
    if (w < x && w < y)
    {
      smallest = w;
    }
    else if (x < w && x < y)
    {
      smallest = x;
    }
    else if (y < w && y < x)
    {
      smallest = y;
    }
    return smallest;
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    // mc.myMethod(3,9);
    // answer 2, 3
    System.out.println("Smallest is: " + mc.getSmallestNumber(78, 44, 33));
    System.out.println("Smallest is: " + mc.getSmallestNumber(-2, 3, 0));
    System.out.println("Smallest is: " + mc.getSmallestNumber(55, 23, 123));
    System.out.println("Smallest is: " + mc.getSmallestNumber(44, 44, 20));
    System.out.println("Smallest is: " + mc.getSmallestNumber(34, 34, 34));
    System.out.println("Smallest is: " + mc.getSmallestNumber(11, 11, 55));
  }
}
