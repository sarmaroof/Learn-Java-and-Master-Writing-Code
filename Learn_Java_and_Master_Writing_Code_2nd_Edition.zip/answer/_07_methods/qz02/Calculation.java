package answer._07_methods.qz02;

class Calculation
{
  int i = 5;
  int i2 = 3;

  int getResult()
  {
    i++;
    if (i <= i2)
    {
      return i * i2;
    }
    else if ((i + i2) >= 9)
    {
      return i + i2 + 5;
    }
    return i * i2 + 3;
  }
  // answer 1
  int calculate(int x, int y)
  {
    return x * y;
  }
  public static void main(String[] args)
  {
    Calculation cal = new Calculation();
    System.out.println(cal.getResult());
    // answer 2
    System.out.println("The answer is: ");
    System.out.println("22 * 4  = " + cal.calculate(22, 4));
    // answer 3
    System.out.println("9 * 12  = " + cal.calculate(9, 12));
    System.out.println("41 * 11 = " + cal.calculate(41, 11));
  }
}
