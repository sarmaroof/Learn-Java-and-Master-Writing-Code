package answer._07_methods.assignment;

class Gold
{
  double ozGold = 1300.00; // the price of an ounce of gold

  // answer 1
  
  double getAmountOunceByPrice(double price)
  {
    return price / ozGold;
  }
  public static void main(String[] args)
  {
    Gold gd = new Gold();
    // answer 2
    System.out.println("$ 7150 = " + gd.getAmountOunceByPrice(7150));
    System.out.println("$ 1300 = " + gd.getAmountOunceByPrice(1300));
    System.out.println("$ 2600 = " + gd.getAmountOunceByPrice(2600));
    System.out.println("$ 5525 = " + gd.getAmountOunceByPrice(5525));
  }
}
