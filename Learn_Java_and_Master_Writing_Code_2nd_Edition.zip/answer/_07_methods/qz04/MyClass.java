package answer._07_methods.qz04;

class MyClass
{
  int x = 2;

  void print()
  {
    for (int i = 0; i <= 3; i++)
    {
      if (i < 2)
      {
        x++;
      }
      else
      {
        x += 2;
      }
    }
    System.out.print(x);
  }
  // answer 1,2
  int getGreaterNumber(int x, int y)
  {
    if (x > y)
    {
      return x;
    }
    else if (y > x)
    {
      return y;
    }
    else
    {
      return -1;
    }
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    // answer 3
    System.out.println(mc.getGreaterNumber(57, 57));
    System.out.println(mc.getGreaterNumber(49, 22));
    System.out.println(mc.getGreaterNumber(7, 89));
    System.out.println(mc.getGreaterNumber(0, -3));
  }
}
