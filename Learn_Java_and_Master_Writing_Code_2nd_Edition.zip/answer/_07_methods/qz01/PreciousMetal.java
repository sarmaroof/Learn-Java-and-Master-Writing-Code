package answer._07_methods.qz01;

class PreciousMetal
{
  double ozGold = 1300.0; // the price of one ounce of gold
  double ozSilver = 20.0; // the price of one ounce of silver
  double ozPlatinum = 936; // the price of one ounce of platinum
  boolean isGold = true;

  double getMetalPrice(boolean isGold, int ounce)
  {
    if (isGold)
    {
      return ozGold * ounce;
    }
    else
    {
      return ozSilver * ounce;
    }
  }
  // answer 1
  double getPlatinumPrice(double ounce)
  {
    return ounce * ozPlatinum;
  }
  public static void main(String[] args)
  {
    PreciousMetal pm = new PreciousMetal();
    System.out.print(pm.getMetalPrice(false, 4));
    System.out.print(", ");
    System.out.println(pm.getMetalPrice(true, 2));
    // answer 2, 3
    System.out.println("5.5 oz: " + "$ " + pm.getPlatinumPrice(5.5));
    System.out.println("4.5 oz: " + "$ " + pm.getPlatinumPrice(4.5));
    System.out.println("6.0 oz: " + "$ " + pm.getPlatinumPrice(6.0));
  }
}
