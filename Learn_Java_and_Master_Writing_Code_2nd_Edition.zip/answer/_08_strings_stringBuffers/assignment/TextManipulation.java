package answer._08_strings_stringBuffers.assignment;

class TextManipulation
{
  void stringDemo()
  {
    String text = "Brazil $ is $ one $of the largest country in the $ world.";
    System.out.println("Upper case: " + text.toUpperCase());
    System.out.println("Lower case: " + text.toLowerCase());
    System.out.println("Number chars: " + text.length());
    System.out.println("Remove $: " + text.replace("$", ""));
    System.out.println("Remove first 14 chars: " + text.substring(14));
    System.out.println("Return only largest country:" + text.substring(26, 41));
    System.out.println("The index of the first $:" + text.indexOf("$"));
    System.out.println("The index of the Last $:" + text.lastIndexOf("$"));
    System.out.println("Replace Brazil:" + text.replace("Brazil", "Canada"));
  }
  public static void main(String[] args)
  {
    TextManipulation tmObject = new TextManipulation();
    tmObject.stringDemo();
  }
}
