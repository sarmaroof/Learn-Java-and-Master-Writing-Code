package answer._08_strings_stringBuffers.qz04;

class MyClass
{
  String str = "He$llo $World$";

  void myMethod()
  {
    System.out.print(str.replace("$", ""));
  }
  // answer 1
  String replaceEuroWithDollar(String str)
  {
    return str.replace("�", "$");
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    // mc.myMethod();
    // answer 2
    String str = mc.replaceEuroWithDollar("� 233, � 12, � 90, � 62");
    System.out.print(str);
  }
}
