package answer._08_strings_stringBuffers.qz06;

class MyClass
{
  StringBuffer sb = new StringBuffer();
  StringBuffer sb2 = new StringBuffer("Jack");

  void myMethod()
  {
    sb.append("Elvis ");
    sb2.append(" Ben");
    sb.append(22);
    // Answer 1
    sb.append(" music");
    // Answer 2
    sb2.append(" 2000");
    System.out.print(sb + ", " + sb2);
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.myMethod();
  }
}
