package answer._08_strings_stringBuffers.qz08;

class MyClass
{
  StringBuffer sb = new StringBuffer("He was her friend");

  void myMethod()
  {
    // insert code here
    System.out.print(sb);
  }
  // answer 1
  String convertSbToString(StringBuffer sb)
  {
    return sb.toString();
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    // mc.myMethod();
    // answer 2
    String strSb = mc.convertSbToString(mc.sb);
    System.out.print(strSb);
  }
}
