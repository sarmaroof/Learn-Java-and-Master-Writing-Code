package answer._08_strings_stringBuffers.qz05;

class MyClass
{
  String str = " the subconscious mind ";

  void myMethod()
  {
    int strLength = str.length();
    str = str.toUpperCase();
    str = str.trim();
    System.out.print(strLength + " " + str + " " + str.length());
  }
  // Answer 1
  int getNrCharacter(String str)
  {
    return str.length(); // index starts from 0
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    // mc.myMethod();
    // Answer 2a
    int quote1 = mc.getNrCharacter("What we think, we become.");
    System.out.println("The first quote: " + quote1 + " characters");
    // Answer 2b
    int quote2 = mc.getNrCharacter("Logic will get you from A to B. " +
        "Imagination will take you everywhere");
    System.out.print("The second quote: " + quote2 + " characters");
  }
}
