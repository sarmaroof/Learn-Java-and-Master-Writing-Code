package answer._08_strings_stringBuffers.qz01;

class Quote
{
  String strQuote = "The weak can never forgive";
  // answer 1
  String myStr = "I feel good";

  void myMethod()
  {
    System.out.print(strQuote.charAt(4));
    System.out.print(", " + strQuote.indexOf('k'));
    System.out.print(", " + strQuote.indexOf('e'));
  }
  public static void main(String[] args)
  {
    Quote qt = new Quote();
    // ms.myMethod();
    // answer 2
    System.out.print(qt.myStr.charAt(7));
    // answer 3
    System.out.print(", " + qt.myStr.indexOf('l'));
  }
}
