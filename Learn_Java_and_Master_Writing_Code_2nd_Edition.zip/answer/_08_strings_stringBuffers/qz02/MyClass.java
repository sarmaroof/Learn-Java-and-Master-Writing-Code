package answer._08_strings_stringBuffers.qz02;

class MyClass
{
  String str1 = "Jack";
  String str2 = new String("Jack");

  void myMethod()
  {
    if (str1 == str2)
    {
      System.out.print("X");
    }
    if (str1.equals(str2))
    {
      System.out.print("Y");
    }
    else
    {
      System.out.print("Z");
    }
  }
  // Answer 1
  boolean compareTwoStrings(String s1, String s2)
  {
    return s1.equals(s2);
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    // mc.myMethod();
    // Answer 2
    System.out.println(mc.compareTwoStrings("France", "france"));
    // Answer 3
    System.out.println(mc.compareTwoStrings("Hello", "Hello"));
    System.out.println(mc.compareTwoStrings("123Str", "1234Str"));
    System.out.println(mc.compareTwoStrings("My friend", "My friend"));
  }
}
