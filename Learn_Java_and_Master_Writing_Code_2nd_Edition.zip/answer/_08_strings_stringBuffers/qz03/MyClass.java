package answer._08_strings_stringBuffers.qz03;

class MyClass
{
  String strQuote = "We cannot solve our problems with the same " +
      "thinking we used when we created them. Albert Einstein";

  void myMethod()
  {
    System.out.println(strQuote.substring(21, 26));
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.myMethod();
    // answer 1
    System.out.print(mc.strQuote.substring(82, 97));
  }
}
