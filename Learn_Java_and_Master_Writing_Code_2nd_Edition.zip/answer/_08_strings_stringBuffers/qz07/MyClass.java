package answer._08_strings_stringBuffers.qz07;

class MyClass
{
  StringBuffer sb = new StringBuffer("He is friend.");
  // answer 1
  StringBuffer sb2 = new StringBuffer("He is from ,,, India");

  void myMethod()
  {
    // insert code here
    System.out.print(sb);
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    // mc.myMethod();
    // answer 2
    System.out.print(mc.sb2.delete(11, 15));
  }
}
