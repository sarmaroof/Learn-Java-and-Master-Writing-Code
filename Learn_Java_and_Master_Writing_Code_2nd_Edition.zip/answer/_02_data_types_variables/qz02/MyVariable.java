package answer._02_data_types_variables.qz02;

class MyVariable
{
  byte b = 122;
  short s;
  float f1 = 3.50f;
  float f2 = 43.9f;
  double d = 335.35;
  char myChar = 'Q';

  public static void main(String[] args)
  {
    MyVariable mv = new MyVariable();
    
    System.out.print(mv.b + ", ");
    // System.out.print(myChar + ", ");
    System.out.print(mv.s + ", ");
    System.out.print(mv.f1 + ", ");
    // System.out.print(myChar + ", ");
    System.out.print(mv.f2 + ", ");
    System.out.println(mv.d);
    // Answer
    System.out.print(mv.myChar);
  }
}
