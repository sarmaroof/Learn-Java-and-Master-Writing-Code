package answer._02_data_types_variables.qz01;

class Worker
{
  boolean isMarried;
  int age = 29;
  long bankAccount = 6552;
  double wage = 110.30;
  char gender = 'm'; // female: f, male: m

  public static void main(String[] args)
  {
    Worker wk = new Worker();
    
    System.out.print(wk.age + ", ");
    System.out.print(wk.bankAccount + ", ");
    System.out.print(wk.wage + ", ");
    System.out.print(wk.isMarried + ", ");
    System.out.println(wk.gender);
    // Answer
    System.out.print("Het antwoord: ");
    boolean isForeigner = true;
    System.out.print(isForeigner);
  }
}
