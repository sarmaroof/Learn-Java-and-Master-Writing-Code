package answer._02_data_types_variables.qz04;

class MyClass
{
  int i1 = 7;
  int i2 = 12;

  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    
    mc.i1 = 9;
    mc.i2 = 8;
    mc.i1 = mc.i1 - 3;
    mc.i2 = mc.i2 + mc.i1;
    
    System.out.print(mc.i1 + ", ");
    System.out.print(mc.i2 + " ");
  }
}
