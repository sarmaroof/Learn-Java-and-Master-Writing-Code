package answer._02_data_types_variables.qz03;

class MyClass
{
  int i;
  double d;
  boolean b;

  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    
    System.out.print(mc.i + ", ");
    System.out.print(mc.d + ", ");
    System.out.println(mc.b);
    // Answer
    double myVar = 1344.98;
    char myVar2 = 'g';
    int myVar3 = 766;
    
    System.out.print("The answer: ");
    System.out.print(myVar + ", ");
    System.out.print(myVar2 + ", ");
    System.out.print(myVar3);
  }
}
