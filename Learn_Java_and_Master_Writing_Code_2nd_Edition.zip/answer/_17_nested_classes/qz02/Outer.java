package answer._17_nested_classes.qz02;

public class Outer
{
  // answer
  private int a = 5;

  Outer()
  {
    a += 4;
  }

  class Inner
  {
    Inner()
    {
      a++;
    }
  }

  public static void main(String[] args)
  {
    Outer outer = new Outer();
    Inner inner = outer.new Inner();
    System.out.print(outer.a);
  }
}
