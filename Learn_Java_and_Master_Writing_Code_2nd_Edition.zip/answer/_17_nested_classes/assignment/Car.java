package answer._17_nested_classes.assignment;

public class Car
{
  String brand;
  String manufactureYear;
  String licensePlate;

  public Car(String brand, String manufactureYear, String licensePlate)
  {
    this.brand = brand;
    this.manufactureYear = manufactureYear;
    this.licensePlate = licensePlate;
  }
  public void printInfo()
  {
    System.out.println("Brand:               " + brand);
    System.out.println("Year of manufacture: " + manufactureYear);
    System.out.println("License plate:       " + licensePlate);
  }

  public class Engine
  {
    String engineCode;
    String fuel;

    public Engine(String engineCode, String fuel)
    {
      this.engineCode = engineCode;
      this.fuel = fuel;
    }
    public void printInfo()
    {
      System.out.println("Engine code:         " + engineCode);
      System.out.println("Fuel:                " + fuel);
    }
  }

  public static void main(String[] args)
  {
    Car car = new Car("BMW", "2016", "XN-45-489");
    Engine engine = car.new Engine("N45B20A", "Petrol");
    car.printInfo();
    engine.printInfo();
  }
}
