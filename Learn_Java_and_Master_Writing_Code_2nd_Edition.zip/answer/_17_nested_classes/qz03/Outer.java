package answer._17_nested_classes.qz03;

class Outer
{
  private int x = 2;

  Outer()
  {
    this(3);
    x++;
  }
  Outer(int i)
  {
    x += i;
    System.out.print(x);
  }

  class Inner
  {
    public void methodA()
    {
      x -= 3;
      System.out.print(x);
    }
  }

  public static void main(String[] args)
  {
    // answer
    Outer.Inner inner = new Outer(7).new Inner();
    inner.methodA();
  }
}
