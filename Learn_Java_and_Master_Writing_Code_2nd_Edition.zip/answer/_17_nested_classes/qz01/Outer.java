package answer._17_nested_classes.qz01;

public class Outer
{
  int x;

  Outer()
  {
    x += 4;
  }

  class Inner
  {
    int y;

    public void methodA()
    {
      x++;
      System.out.print(x);
    }
  }

  public static void main(String[] args)
  {
    Outer.Inner inner = new Outer().new Inner();
    inner.methodA();
  }
}
