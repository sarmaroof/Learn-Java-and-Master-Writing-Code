package answer._17_nested_classes.qz04;

class Outer
{
  static int x = 3;

  Outer()
  {
    x += 4;
  }

  static class Nested
  {
    Nested()
    {
      x += 2;
    }
    int method(int i)
    {
      System.out.print(x);
      return i + x;
    }
  }

  public static void main(String[] args)
  {
    Outer outer = new Outer();
    Outer.Nested nested = new Outer.Nested();
    System.out.print(nested.method(2));
  }
}
