package answer._03_operators.qz03;

class MyClass
{
  public static void main(String[] args)
  {
    int x = 4;
    int y = 6;
    
    x--;
    y++;
    // Answer
    System.out.print("The answer is: ");
    x++;
    System.out.print(x + ", " + y);
    // x++;
  }
}
