package answer._03_operators.qz09;

class MyClass
{
  public static void main(String[] args)
  {
    int x = 6;
    int x2 = 4;
    int y = (x == 3) ? 24 : 8;
    int z = (x2 == 4) ? 33 : 21;
    
    System.out.print(y);
    System.out.print(z);
  }
}
