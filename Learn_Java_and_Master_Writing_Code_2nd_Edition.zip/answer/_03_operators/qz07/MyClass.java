package answer._03_operators.qz07;

class MyClass
{
  public static void main(String[] args)
  {
    int i1 = 3;
    int i2 = 5;
    int i3 = 12;
    int i4 = 20;
    
    i1 += 4;
    i2 *= 3;
    i3 /= 3;
    i4 -= 12;
    // Answer
    System.out.print("The answer is: ");
    i1++;
    i2 -= 3;
    i3 *= 2;
    i4 /= 4;
    
    System.out.print(i1 + ", ");
    System.out.print(i2 + ", ");
    System.out.print(i3 + ", ");
    System.out.print(i4 + " ");
  }
}
