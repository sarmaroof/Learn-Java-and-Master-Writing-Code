package answer._03_operators.qz06;

class MyClass
{
  public static void main(String[] args)
  {
    boolean isOld = true;
    int x = 5;
    int y = 14;
    int z = 17;
    
    if (y > x && z > y && (x + 12) >= z)
    {
      System.out.print("P");
    }
    if (x >= 6 || z <= y || z <= 18)
    {
      System.out.print("Q");
    }
    if (!isOld || y > z)
    {
      System.out.print("R");
    }
  }
}
