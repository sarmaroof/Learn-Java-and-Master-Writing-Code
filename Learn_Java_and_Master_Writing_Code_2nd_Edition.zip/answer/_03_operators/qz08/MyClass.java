package answer._03_operators.qz08;

class MyClass
{
  public static void main(String[] args)
  {
    int i1 = 22;
    int i2 = 17;
    int i3 = 30;
    
    i1 %= 6;
    i2 %= 5;
    i3 %= 6;
    
    // Answer
    System.out.print("The answer is: ");
    i1 %= 3;
    i2 %= 7;
    System.out.print(i1 + " ");
    System.out.print(i2 + " ");
    System.out.print(i3 + " ");
  }
}
