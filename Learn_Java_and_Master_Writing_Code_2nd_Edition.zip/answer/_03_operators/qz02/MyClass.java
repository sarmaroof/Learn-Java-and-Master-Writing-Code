package answer._03_operators.qz02;

class MyClass
{
  public static void main(String[] args)
  {
    System.out.print(21 % 7 + ", ");
    System.out.print(12 % 5 + ", ");
    System.out.println(23 % 6);
    // Answer
    System.out.print("The answer is: ");
    System.out.print(44 % 10 + ", ");
    System.out.print(7 % 2 + ", ");
    System.out.print(30 % 3);
  }
}
