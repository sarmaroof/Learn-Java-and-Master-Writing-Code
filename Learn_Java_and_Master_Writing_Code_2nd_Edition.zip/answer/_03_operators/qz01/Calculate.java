package answer._03_operators.qz01;

class Calculate
{
  public static void main(String[] args)
  {
    int x = 20;
    int y = 5;
    int z = 3;
    double d = 2.2;
    double d2 = 3.7;
    
    System.out.print(x / y + ", ");
    System.out.print(x * z + ", ");
    System.out.print(x + y - z + ", ");
    System.out.print(x / y + z * 2 + ", ");
    System.out.println(d2 - d);
    // Answer
    System.out.print("The answer is: ");
    System.out.print(x * y / 10 + ", ");
    System.out.print(2 * d2 + 2.5 + ", ");
    System.out.print(z * 3 - 6);
  }
}
