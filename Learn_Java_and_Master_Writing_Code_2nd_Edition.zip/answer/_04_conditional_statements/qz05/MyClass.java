package answer._04_conditional_statements.qz05;

class MyClass
{
  public static void main(String[] args)
  {
    int i = 1;
    int i2 = 4;
    int x = 2;
    
    if (i == (i2 - 3) && i2 > 5)
    {
      x++;
    }
    // answer
    else if ((i + i2) == 5)
    {
      System.out.print("D");
    }
    else if (i2 == 4)
    {
      x += 2;
    }
    // wrong answer, check out why
    /*else if((i + i2) == 5) 
     {
     	System.out.print("D");
     }*/
    else if (i2 > 3)
    {
      x += 3;
    }
    // wrong answer, check out why
    /*else if((i + i2) == 5) 
     {
     	System.out.print("D");
     }*/
    else
    {
      x += 4;
    }
    System.out.print(x);
  }
}
