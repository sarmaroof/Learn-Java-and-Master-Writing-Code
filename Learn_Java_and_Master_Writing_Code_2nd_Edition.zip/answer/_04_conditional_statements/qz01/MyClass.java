package answer._04_conditional_statements.qz01;

class MyClass
{
  public static void main(String[] args)
  {
    int i = 2;
    // Answer
    if (i == 2)
    {
      System.out.print("N");
    }
    if (i > 0)
    {
      System.out.print("X");
      System.out.print("Y");
    }
    if (i > 3)
    {
      System.out.print("Z");
    }
  }
}
