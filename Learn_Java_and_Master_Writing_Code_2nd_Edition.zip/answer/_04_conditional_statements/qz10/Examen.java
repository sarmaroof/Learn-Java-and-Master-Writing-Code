package answer._04_conditional_statements.qz10;

class Examen
{
  public static void main(String args[])
  {
    // answer 3
    char grade = 'N';
    
    switch (grade)
    {
      case 'A':
        System.out.print("Excellent! ");
        break;
      case 'B':
        System.out.print("Very good ");
        break;
      // answer 1
      case 'C':
        System.out.print("Good ");
        break;
      // answer 2
      case 'D':
        System.out.print("Fair ");
        break;
      case 'E':
        System.out.print("Try again ");
        break;
      default:
        System.out.print("Invalid ");
    }
  }
}
