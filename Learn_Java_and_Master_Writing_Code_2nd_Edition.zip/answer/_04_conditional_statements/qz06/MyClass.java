package answer._04_conditional_statements.qz06;

class MyClass
{
  public static void main(String[] args)
  {
    int i1 = 3;
    int i2 = 9;
    int i3 = 12;
    int x = 0;
    
    if (x > -1)
    {
      x++;
      if (i3 == (i1 + i2))
      {
        x += 4;
        if (i1 < 5)
        {
          x += 2;
          // first possible answer
          System.out.print(x);
        }
        else if (i2 == 9)
        {
          x++;
        }
        else
        {
          x -= 2;
        }
        // second possible answer
        // system.out.print(x);
        x -= 6;
      }
      if (i3 < 10)
      {
        x += 7;
      }
      else
      {
        x += 5;
      }
    }
    System.out.print(x);
  }
}
