package answer._04_conditional_statements.qz03;

class MyClass
{
  public static void main(String[] args)
  {
    char c1 = 'g';
    char c2 = 'h';
    
    if (c1 == 'k')
    {
      System.out.print('w');
    }
    if (c2 == 'h')
    {
      System.out.print('x');
      System.out.print('p');
    }
    if (c1 != c2)
    {
      System.out.print('y');
    }
    // Answer
    if (c1 == 'd')
    {
      // ignored
    }
    else
    {
      System.out.print('z');
    }
  }
}
