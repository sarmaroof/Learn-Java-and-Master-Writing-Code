package answer._04_conditional_statements.qz04;

class MyClass
{
  public static void main(String[] args)
  {
    int a = 2;
    int b = 2;
    int x = 5;
    
    // answer 1
    if (a != b)
    {
      x++;
    }
    // answer 2
    else if (b >= 1)
    {
      System.out.print("X");
    }
    else if (b == 2)
    {
      x += 2;
    }
    // wrong answer check out why
    /*
    else if(b >= 1) {
    	System.out.print("X");
    }*/
    else
    {
      x += 3;
    }
    System.out.print(x);
  }
}
