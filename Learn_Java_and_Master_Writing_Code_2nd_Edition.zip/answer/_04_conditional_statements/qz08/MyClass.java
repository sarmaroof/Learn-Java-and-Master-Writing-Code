package answer._04_conditional_statements.qz08;

class MyClass
{
  public static void main(String[] args)
  {
    int x = 8;
    
    switch (x)
    {
      case 6:
        x += 5;
      case 7:
        x += 3;
      case 8:
        x += 2;
        // answer 2
        break;
      case 9:
        x++;
        // answer 1
        break;
      default:
        x += 4;
    }
    System.out.print(x);
  }
}
